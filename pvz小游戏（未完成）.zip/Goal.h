#include<easyx.h>
#include"Vec.h"
#include"Rect.h"
class Goal
{
private:
	Goal() = default;
	Goal(Goal&) = default;
public:
	static Goal* create();
	static Goal* create(const char* filename);//�������

	bool init();
	void drawTick();
	void eventTick(float delta);

	bool setImg(const char* filename);//����ͼƬ
	void setPosition(const Vec& pos) { m_position = pos; };//��������
private: 
	IMAGE m_brainimg;
	Vec m_position;
public:
	Rect getBox()
	{
		return Rect(m_position.x, m_position.y, m_brainimg.getwidth(), m_brainimg.getheight());
	}
};
