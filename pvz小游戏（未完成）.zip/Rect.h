#pragma once
class Rect
{
public:
	Rect() : x(0.0f), y(0.0f), w(0.0f), h(0.0f) {}
	Rect(float x,float y,float w,float h):x(x),y(y),w(w),h(h){}
	bool isTouch(const Rect& rect)const
	{
		if (x <= rect.x + rect.w && rect.x <= x + w && y <= rect.y + rect.h && rect.y <= y + h)
		{
			return true;
		}//��ײ�ж�
		return false;
	}
	float x, y, w, h;
};

