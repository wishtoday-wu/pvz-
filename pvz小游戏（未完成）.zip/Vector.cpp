#include "Vector.h"
class Vec
{
public:
	Vec() :x(0.0f), y(0.0f) {}
	Vec(float x, float y) :x(x), y(y){}

	float x, y;  
};