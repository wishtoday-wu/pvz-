#include "zombie.h"
#include"Tools.h"
Zombie* Zombie::create()
{
	Zombie* zombie = new Zombie;
	if (zombie->init())
		return zombie;
	delete zombie;
	return nullptr;
}//�޲�����ʼ�����
Zombie* Zombie::create(const char* filename)
{
	Zombie* zombie = new Zombie;
	if (zombie->init() && zombie->setImg(filename))
		return zombie;
	delete zombie;
	return nullptr;
}//�в���
bool Zombie::init()
{
	return true;
}
void Zombie::drawTick()
{
	Tools::putimage_alpha(m_position.x, m_position.y, &m_Image);
}
void Zombie::eventTick(float detla)
{
	if(m_Ismove)
	m_position.x -= 0.05f * detla;
}

bool Zombie::setImg(const char* filename)
{
	loadimage(&m_Image, filename);
	return true;
}//�����ز��ļ��趨ͼƬ