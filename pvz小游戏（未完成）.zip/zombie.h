#pragma once
#include<easyx.h>
#include"Vec.h"
#include"Rect.h"
class Zombie
{
private:
	Zombie() = default;
	Zombie(Zombie&) = default;
public:
	static Zombie* create();
	static Zombie* create(const char* filename);//�������

	bool init();
	void drawTick();
	void eventTick(float delta);

	bool setImg(const char* filename);//����ͼƬ
	void setPosition(const Vec& pos) { m_position = pos; };//��������
	void setIsmove(bool ismove) { m_Ismove = ismove; };
private:
	IMAGE m_Image;
	Vec m_position;
	bool m_Ismove = true;
public:
	Rect getBox()
	{
		return Rect(m_position.x, m_position.y, m_Image.getwidth(), m_Image.getheight());
	}
};
